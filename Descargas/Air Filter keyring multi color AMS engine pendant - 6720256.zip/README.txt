Air Filter keyring multi color AMS engine pendant by ZECIORTECH on Thingiverse: https://www.thingiverse.com/thing:6720256

Summary:
Scale it if you want (on picture, one is 100% scale and 2nd 150%)I used Rosa3D filaments - PLA Red Jasper Satin and PLA Silk Navy Blue to make it similar to real as possible