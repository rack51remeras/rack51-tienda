11mm Rims - 1/64 Scale Wheels for Diecast vehicle - Hot Wheels by CaptainAhmazing on Thingiverse: https://www.thingiverse.com/thing:4138689

Summary:
These rims are sized for 1/64 diecast vehicles. You may want to model a tire around it or grab the tire from my other wheel. Of course you could always resize it for larger rc or model vehicles.