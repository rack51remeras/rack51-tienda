American Racer Vector Rims And Tires by Preston1948 on Thingiverse: https://www.thingiverse.com/thing:4123254

Summary:
Made these for a homemade general lee model out of soda cans. (https://www.thingiverse.com/thing:3935618) They pop together.Print tires at zero % infill in TPU for flexibleness and the way thickness to 3 or 4 any more an  you won't be able to mount them on the rims.Rims in black PLA with the detail as high as possible as slow as you can to get the quality high enough.Use wooden skewer as axel.